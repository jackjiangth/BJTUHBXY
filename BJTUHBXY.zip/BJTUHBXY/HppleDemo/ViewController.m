//
//  ViewController.m
//  HppleDemo
//
//  Created by Vytautas Galaunia on 11/25/14.
//
//

#import "ViewController.h"
#import "HBHttpNetWorking.h"

@interface ViewController ()


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    

    
    // 目录页
    //[session myGetSession:@"http://www.bjtuhbxy.cn/news_more.asp?lm2=74"];
    
  //  HBHttpNetWorking *hbNet = [[HBHttpNetWorking alloc] init];
    //[hbNet parseHttpContent:@"http://www.bjtuhbxy.cn/news_more.asp?lm2=74"];
    
    //NSLog(@"%@",hbNet.contentTitles);
    
    //[hbNet parseHttpContentOfPage:@"http://www.bjtuhbxy.cn/News_View.asp?NewsID=1967"];
    
  //  [hbNet parseHttpContentOfPage:@"http://www.bjtuhbxy.cn/News_View.asp?NewsID=1967"];
    
        
    
 

}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
