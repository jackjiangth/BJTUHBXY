//
//  EducationDetailModel.m
//  HppleDemo
//
//  Created by jack on 16/4/19.
//
//

#import "EducationDetailModel.h"

@implementation EducationDetailModel

@end
