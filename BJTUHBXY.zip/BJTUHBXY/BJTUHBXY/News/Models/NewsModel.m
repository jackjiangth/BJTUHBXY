//
//  NewsModel.m
//  HppleDemo
//
//  Created by jack on 16/4/19.
//
//

#import "NewsModel.h"

@implementation NewsModel

@end
