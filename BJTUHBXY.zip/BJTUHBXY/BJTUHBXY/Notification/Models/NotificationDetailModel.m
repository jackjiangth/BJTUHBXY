//
//  NotificationDetailModel.m
//  HppleDemo
//
//  Created by jack on 16/4/19.
//
//

#import "NotificationDetailModel.h"

@implementation NotificationDetailModel

@end
