//
//  QRViewController.h
//  HppleDemo
//
//  Created by lanou3g on 16/4/20.
//
//

#import <UIKit/UIKit.h>

@interface QRViewController : UIViewController

@end
