//
//  DetailTableViewController.h
//  HppleDemo
//
//  Created by lanou3g on 16/4/21.
//
//

#import <UIKit/UIKit.h>

@interface DetailTableViewController : UITableViewController

@property(nonatomic,assign)NSInteger index;
@property(nonatomic,assign)NSInteger num;

@end
