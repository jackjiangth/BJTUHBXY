//
//  HomePageViewController.h
//  HppleDemo
//
//  Created by jack on 16/4/19.
//
//

#import <UIKit/UIKit.h>

@interface HomePageViewController : UIViewController
@property(nonatomic,strong)UIButton *button1;
@property(nonatomic,strong)UIButton *button2;
@property(nonatomic,strong)UIButton *button3;
@property(nonatomic,strong)UIButton *button4;
@end
