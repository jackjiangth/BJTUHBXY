//
//  CollectionDetailView.m
//  HppleDemo
//
//  Created by jack on 16/4/19.
//
//

#import "CollectionDetailView.h"

@implementation CollectionDetailView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
