//
//  HomePageCarouselModel.h
//  HppleDemo
//
//  Created by jack on 16/4/19.
//
//

#import <Foundation/Foundation.h>

@interface HomePageCarouselModel : NSObject

@end
