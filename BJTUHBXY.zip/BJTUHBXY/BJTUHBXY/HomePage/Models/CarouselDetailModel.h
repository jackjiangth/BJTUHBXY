//
//  CarouselDetailModel.h
//  HppleDemo
//
//  Created by jack on 16/4/19.
//
//

#import <Foundation/Foundation.h>

@interface CarouselDetailModel : NSObject
//轮播图model
@property(nonatomic,strong)NSString *url;//链接地址
@property(nonatomic,strong)NSString *image;//图片地址

@end
