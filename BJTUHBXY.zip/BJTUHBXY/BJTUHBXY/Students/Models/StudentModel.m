//
//  StudentModel.m
//  HppleDemo
//
//  Created by jack on 16/4/19.
//
//

#import "StudentModel.h"

@implementation StudentModel

@end
